package com.example.bedrockminable.mixin;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.Material;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.block.AbstractBlock;

@Mixin(Blocks.class)
public class BedrockMixin {
    @Inject(method = "<clinit>", at = @At("TAIL"))
    private static void modifyBedrock(CallbackInfo ci) {
        // 进一步确保基岩属性被正确修改
        AbstractBlock.Settings settings = Block.Settings.create(Material.STONE)
                .strength(20.0f, 1000.0f)
                .requiresTool()
                .harvestLevel(4)
                .harvestTool(net.minecraft.item.ToolType.PICKAXE);
        
        // 通过反射替换基岩的设置
        try {
            java.lang.reflect.Field field = Blocks.class.getDeclaredField("BEDROCK");
            field.setAccessible(true);
            field.set(null, new Block(settings) {});
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

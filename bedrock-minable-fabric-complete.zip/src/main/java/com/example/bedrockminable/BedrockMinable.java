package com.example.bedrockminable;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.block.Blocks;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.block.Block;
import net.minecraft.server.network.ServerPlayerEntity;

public class BedrockMinable implements ModInitializer {
    public static final String MOD_ID = "bedrock_minable";

    @Override
    public void onInitialize() {
        // 修改基岩属性
        modifyBedrockProperties();
        
        // 注册服务器启动事件
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            // 向所有在线玩家发送提示
            server.getPlayerManager().broadcast(Text.literal("基岩现在可以被开采了！使用下界合金镐效果最佳。"), false);
        });
    }
    
    private void modifyBedrockProperties() {
        Block bedrock = Blocks.BEDROCK;
        
        // 使用反射修改硬度（Fabric中直接设置的方法）
        try {
            // 修改硬度为20.0f（原版为-1.0f，表示不可破坏）
            bedrock.setHardness(20.0f);
            
            // 修改爆炸抗性
            bedrock.setResistance(1000.0f);
            
            // 设置开采工具要求
            bedrock.setRequiredTool(true);
            bedrock.setHarvestLevel(4); // 4对应下界合金工具
            bedrock.setHarvestTool(TagKey.of(Registries.ITEM_GROUP.getKey(), new Identifier("minecraft:pickaxes")));
        } catch (Exception e) {
            System.err.println("修改基岩属性时出错: " + e.getMessage());
        }
    }
}
